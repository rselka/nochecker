import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

class TicketVendingMachine {

    private Payment payment;
    private final Scanner scanner = new Scanner(System.in);
    private static final Statistics statistics = new Statistics();

    public TicketVendingMachine() {
        payment = new Payment();
    }

    public void displayTickets() {
        int ticketPurchaseCount = 0; // Um die Anzahl der Käufe zu zählen

        while (true) {
            ticketPurchaseCount++;
            System.out.println("Ticket Purchase #" + ticketPurchaseCount +" Please press enter, if is necessary");

            // 1. Entering the Data of customers
            Customer customer = inputsData();
            if (customer == null) {
                System.out.println("The purchase process has been cancelled.");
                continue;
            }

            // 2. Check the age of customer
            else if (!customer.agesChecking()) {
                System.out.println("Customer is under 18 years old. The purchase process has been cancelled.");
                continue;
            }

            // 3. Ticket purchase
            System.out.println("Please select a ticket from the available ticket options:");
            for (int i = 0; i < Statistics.ticketTypes.length; i++) {
                System.out.println(
                        (i + 1) + " : " + Statistics.ticketTypes[i] + " - " + Statistics.ticketPrices[i] + " EUR");
            }

            int ticketChoice = scanner.nextInt();
            scanner.nextLine();

            if (ticketChoice == 0) {
                System.out.println("Ending, please press Enter.");
                break;
            }

            if (ticketChoice < 1 || ticketChoice > Statistics.ticketTypes.length) {
                System.out.println("Invalid ticket option. Please try again.");
                continue;
            }

            if (purchaseTicket(ticketChoice, customer)) {
                statistics.sellTicket(Statistics.ticketTypes[ticketChoice - 1]);
            }
        }
    }

    public boolean purchaseTicket(int ticketChoice, Customer customer) {
        String ticketType = Statistics.ticketTypes[ticketChoice - 1];
        double ticketPrice = Statistics.ticketPrices[ticketChoice - 1];

        System.out.println("The selected ticket is: " + ticketType + ". The price of the ticket is: " + ticketPrice + " EUR" + " Please press Enter");

        int attempts = 3;
        scanner.nextLine();
        while (attempts > 0) {
            System.out.println("Please enter your 8-digit password:");
            String password = scanner.nextLine();
            if (password.equals(customer.getPassword())) {
                break;  // When passwort is correct continue
            } else {
                attempts--;
                System.out.println("Wrong password. Please try again."); // if the password is wrong
                if (attempts == 0) {
                    System.out.println("Maximum number of attempts reached. The purchase process is cancelled.");
                    return false; // if the password goíng wrong 3 times
                }
            }
        }

        while (!payment.isPaymentSufficient(ticketPrice)) {
            System.out.println("Please enter the amount you wish to pay in EUR:");
            double amount = scanner.nextDouble();
            payment.makePayment(amount);
        }

        System.out.println("Payment succesful.");
        double change = payment.getChange(ticketPrice);
        if (change > 0) {
            System.out.println("Your change: " + change + " EUR");
        }
        payment = new Payment();  // Important for Start with the next Costumer after successful sold
        System.out.println(customer.getName() + " purchased: " + ticketType);
        return true;
    }

    // Method to entering the data of customers
    public Customer inputsData() {
        scanner.nextLine();

        System.out.println("Please enter your name:");
        String name = scanner.nextLine();

        System.out.println("Please enter your address:");
        String address = scanner.nextLine();

        System.out.println("Please enter your E-Mail address:");
        String email = scanner.nextLine();

        System.out.println("Please enter your birthday (yyyy-MM-dd) ein:");
        String birthDateStr = scanner.nextLine();

        Date birthDate;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            birthDate = dateFormat.parse(birthDateStr);
        } catch (ParseException e) {
            System.out.println("Invalid date format. The purchase process is cancelled.");
            return null;
        }

        Customer customer = new Customer(name, address, email, birthDate);

        // Outcome the Data of costumer after correct entering
        if (customer.agesChecking()) {
            System.out.println("Customer Details:");
            System.out.println("Name: " + customer.getName());
            System.out.println("Address: " + customer.getAddress());
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Age: " + customer.calculateAge());
            System.out.println("Password: " + customer.getPassword());
        } else {
            return null;
        }
        return customer;
    }
}