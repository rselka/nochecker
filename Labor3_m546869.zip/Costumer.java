import java.util.Date;
import java.util.Random;

class Customer {
    private  String name;
    private  String address;
    private  String email;
    private  Date birthDate;
    private  String password;

    // A constructor in Java is a special method that is defined in a class and is used to initialise
    // objects of this class. A constructor has the same name as the class and is called automatically
    // when a new object of this class is created.

    public Customer(String name, String address, String email, Date birthDate) {  // constructor
        this.name = name;
        this.address = address;
        this.email = email;
        this.birthDate = birthDate;
        this.password = generateRandomPassword();
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }

    public int calculateAge() {
        long ageInMillis = System.currentTimeMillis() - birthDate.getTime();
        long ageInYears = ageInMillis / (1000L * 60 * 60 * 24 * 365); // calculating the age
        return (int) ageInYears;
    }


    public boolean agesChecking() {
        return calculateAge() >= 18; //checking of age, if the user is under 18 the code is ending
    }


    private String generateRandomPassword() {
        Random random = new Random(); // Passwort Generator
        StringBuilder password = new StringBuilder(8);
        for (int i = 0; i < 8; i++) {
            password.append(random.nextInt(10));  // any number between 0-9
        }
        return password.toString();
    }
}