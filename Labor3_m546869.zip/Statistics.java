class Statistics {
    public static final String[] ticketTypes = {"SingleTicket", "DayPass", "WeeklyPass", "MonthlyPass"};
    public static final double[] ticketPrices = {2.50, 5.00, 15.00, 50.00};

    public int[] ticketsSold = new int[ticketTypes.length];
    public double[] ticketsRevenue = new double[ticketTypes.length];
    public double totalRevenue = 0.00;
    public int totalTicketsSold = 0;

    public void sellTicket(String ticketType) {
        int ticketIndex = getTicketIndex(ticketType);

        if (ticketIndex == -1) {
            System.out.println("Invalid ticket option selected. Please try again.");
            return;
        }

        ticketsSold[ticketIndex]++;
        ticketsRevenue[ticketIndex] += ticketPrices[ticketIndex];
        totalRevenue += ticketPrices[ticketIndex];
        totalTicketsSold++; // ticket sold, increase the value in array


        if (totalTicketsSold % 2 == 0) {
            displayStatistics(); // Statistics starts after 5 successful solds
        }
    }

    private int getTicketIndex(String ticketType) {
        for (int i = 0; i < ticketTypes.length; i++) {
            if (ticketTypes[i].equals(ticketType)) {
                return i;
            }
        }
        return -1;
    }

    public void displayStatistics() {
        System.out.println("Ticket sales statistics");
        System.out.println("Total number of tickets sold: " + totalTicketsSold);
        System.out.println("Total Revenue: " + totalRevenue + " EUR");

        for (int i = 0; i < ticketTypes.length; i++) {
            System.out.println(ticketTypes[i] + ": sold: " + ticketsSold[i] + ", revenue: " + ticketsRevenue[i] + " EUR");
        }


        if (totalTicketsSold > 0) {
            System.out.println("Average Ticket Price: " + getAveragePrice() + " EUR");
            // calculating the average Ticket Price after 5 successful solds
        } else {
            System.out.println("Average Ticket Price: N/A (no ticket sold yet.)");
        }
    }

    public double getAveragePrice() {
        if (totalTicketsSold == 0) {
            return 0.0;  // No Ticket sold
        }
        return totalRevenue / totalTicketsSold;
    }
}