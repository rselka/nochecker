class Payment {
    private double amountPaid;

    public Payment() {
        this.amountPaid = 0;  // Start with 0
    }

    public void makePayment(double amount) {
        amountPaid += amount;  // adding the paid amount
    }

    public boolean isPaymentSufficient(double price) {
        return amountPaid >= price;  // The Check that enought money payed
    }

    public double getChange(double price) {
        return amountPaid - price;  // Calculating the change money
    }
}
