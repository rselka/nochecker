public class Main {
    public static void main(String[] args) {
        TicketVendingMachine machine = new TicketVendingMachine();
        machine.displayTickets();
    }
}